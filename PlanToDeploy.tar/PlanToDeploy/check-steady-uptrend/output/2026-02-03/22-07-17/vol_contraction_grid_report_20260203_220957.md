# 网格测试报告

- 生成时间: 2026-02-03 22:09:57
- 参数组合数: 54

## 最优参数（按平均收益）

### 5天收益周期

- bb_window: 20
- num_std: 2.0
- quantile: 0.3
- quantile_window: 120
- vol_ratio_threshold: 1.5
- 信号数: 3148
- 胜率: 52.1%
- 平均收益: 1.22%

### 20天收益周期

- bb_window: 20
- num_std: 2.0
- quantile: 0.2
- quantile_window: 60
- vol_ratio_threshold: 1.5
- 信号数: 1427
- 胜率: 52.9%
- 平均收益: 4.07%

### 60天收益周期

- bb_window: 20
- num_std: 2.0
- quantile: 0.2
- quantile_window: 120
- vol_ratio_threshold: 1.8
- 信号数: 267
- 胜率: 56.2%
- 平均收益: 12.33%
